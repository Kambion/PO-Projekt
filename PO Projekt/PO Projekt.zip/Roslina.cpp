#include <iostream>
#include "Roslina.hpp"

Position Roslina::kolizja(Organizm* other) {
	return martwy;
}